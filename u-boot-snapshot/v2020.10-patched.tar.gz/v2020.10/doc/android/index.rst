.. SPDX-License-Identifier: GPL-2.0+

Android-specific doc
====================

.. toctree::
   :maxdepth: 2

   ab
   avb2
   bcb
   boot-image
   fastboot-protocol
   fastboot
