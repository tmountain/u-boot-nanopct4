/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2017 - Beniamino Galvani <b.galvani@gmail.com>
 */
#ifndef _MESON_I2C_H_
#define _MESON_I2C_H_

#define MESON_I2C_CLK_RATE	167000000

#endif
