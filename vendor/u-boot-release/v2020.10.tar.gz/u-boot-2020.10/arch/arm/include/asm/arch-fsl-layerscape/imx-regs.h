/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 *
 */

#ifndef __ASM_ARCH_FSL_LAYERSCAPE_IMX_REGS_H__
#define __ASM_ARCH_FSL_LAYERSCAPE_IMX_REGS_H__

#define I2C_QUIRK_REG	/* enable 8-bit driver */

#endif /* __ASM_ARCH_FSL_LAYERSCAPE_IMX_REGS_H__ */
