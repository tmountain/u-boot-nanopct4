/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2017 Armadeus Systems
 */

#ifndef __ARCH_ARM_MX6UL_OPOS6UL_H__
#define __ARCH_ARM_MX6UL_OPOS6UL_H__

int opos6ul_board_late_init(void);

#endif
